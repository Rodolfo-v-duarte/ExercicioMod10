import java.util.Scanner;

public class ExercicioMod10 {
    public static void main(String args[]) {
        Scanner nota = new Scanner(System.in);

        System.out.println("**** Programa que divide as notas dos alunos para saber a média anual ****\n");
        System.out.println("Vamos saber quanto foi a sua média!?");
        System.out.println("Para isso vamos precisar das 4 notas do ano letivo.\nPor favor, informar abaixo!\n");

        System.out.println("Digite sua primeira nota: ");
        float nota1 = nota.nextInt();
        System.out.println("Digite sua segunda nota: ");
        float nota2 = nota.nextInt();
        System.out.println("Digite sua terceira nota: ");
        float nota3 = nota.nextInt();
        System.out.println("Digite sua quarta nota: ");
        float nota4 = nota.nextInt();

        float soma = nota1 + nota2 + nota3 + nota4;
        float media = soma / 4;


        if (media >=7 && media <=10){
            System.out.println("Parabéns! Você está aprovado! Sua média é: "+media);
        }
        if (media >=5 && media <7){
            System.out.println("Você está em recuperação! Sua média é: "+media);
        }
        else if (media < 5) {
            System.out.println("Você está reprovado! Sua média é: " + media);
        }
    }
}

